package ru.itis.lectures.githubmvp.view;

/**
 * Created by yasina on 29.03.2016.
 */
public interface WalkView {

    public void showBenefit(int index, boolean isLastBenefit);
    public void finishWalkthrough();

}

package ru.itis.lectures.githubmvp.view;

/**
 * @author Artur Vasilov
 */
public interface LogInView {

    void openRepositoriesScreen();

    void showLoginError();

    void showPasswordError();

}
